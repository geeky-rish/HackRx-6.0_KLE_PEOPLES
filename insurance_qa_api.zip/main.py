from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from core import process_pdf_and_answer_questions
from dotenv import load_dotenv
import os

load_dotenv()

API_KEY = os.getenv("API_KEY")
app = FastAPI()

class QARequest(BaseModel):
    documents: str
    questions: list[str]

@app.post("/hackrx/run")
async def run_qa(request: Request, qa: QARequest):
    auth = request.headers.get("Authorization")
    if not auth or not auth.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing or invalid Authorization header")
    token = auth.split(" ")[1]
    if token != API_KEY:
        raise HTTPException(status_code=403, detail="Invalid API Key")

    try:
        answers = process_pdf_and_answer_questions(qa.documents, qa.questions)
        return JSONResponse(content={"answers": answers})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
